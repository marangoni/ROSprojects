
"use strict";

let DefineSong = require('./DefineSong.js');
let PlaySong = require('./PlaySong.js');
let MotorSetpoint = require('./MotorSetpoint.js');
let ChargingState = require('./ChargingState.js');
let Bumper = require('./Bumper.js');
let Mode = require('./Mode.js');

module.exports = {
  DefineSong: DefineSong,
  PlaySong: PlaySong,
  MotorSetpoint: MotorSetpoint,
  ChargingState: ChargingState,
  Bumper: Bumper,
  Mode: Mode,
};
